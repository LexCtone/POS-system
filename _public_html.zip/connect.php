<?php
$servername = "localhost";
$username = "u429621164_root"; // Use the correct username
$password = "@Svhardware123!"; // Ensure the password is correct
$dbname = "u429621164_sv_hardware_db"; // Use the correct database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
