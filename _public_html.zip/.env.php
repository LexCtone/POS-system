<?php
return [
    'ENCRYPTION_KEY' => 'W3N6R0NaRmRzS2JHck9lTUFNQmFZUVlzZlF1TGJjWlA=',
    // Add other variables as needed
];
